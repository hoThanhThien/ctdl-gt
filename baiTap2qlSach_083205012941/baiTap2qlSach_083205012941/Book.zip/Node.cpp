#include "Node.h"
#include "Book.h"

Node::Node(Book b) : book(b), next(nullptr)
{
	
}
